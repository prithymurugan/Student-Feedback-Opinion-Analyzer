function analyzeFeedback() {

    const text =
        document.getElementById("feedback")
        .value.toLowerCase();

    const positive = [
        "good", "excellent", "useful",
        "interesting", "easy", "helpful"
    ];

    const negative = [
        "bad", "difficult", "poor",
        "boring", "slow", "confusing"
    ];

    let p = 0;
    let n = 0;

    positive.forEach(word => {
        if (text.includes(word)) p++;
    });

    negative.forEach(word => {
        if (text.includes(word)) n++;
    });

    let result;

    if (p > n) {
        result = "Positive Feedback";
    } else if (n > p) {
        result = "Negative Feedback";
    } else {
        result = "Neutral Feedback";
    }

    document.getElementById("result").innerText =
        result;
}